static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#eee8d5", "#002b36" },
	[SchemeSel] = { "#ffffff", "#d33682" },
	[SchemeSelHighlight] = { "#2aa198", "#000000" },
	[SchemeNormHighlight] = { "#2aa198", "#000000" },
	[SchemeOut] = { "#ffffff", "#268bd2" },
	[SchemeMid] = { "#eee8d5", "#000000" },
};
