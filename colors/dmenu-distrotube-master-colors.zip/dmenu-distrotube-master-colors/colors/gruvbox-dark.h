static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#ebdbb2", "#282828" },
	[SchemeSel] = { "#000000", "#b16286" },
	[SchemeSelHighlight] = { "#689d6a", "#000000" },
	[SchemeNormHighlight] = { "#689d6a", "#000000" },
	[SchemeOut] = { "#ffffff", "#458588" },
	[SchemeMid] = { "#ebdbb2", "#1c1f24" },
};
